import Image1 from "./assets/GBA/SIDE/GBA-Side-GBA-Side-ClearBlue_Shell_GBA_0027.jpg";
import Image2 from "./assets/GBA/SIDE/GBA-Side-GBA_Button_ClearPink0027-side.png";
import { useState } from "react";

import "./GBAPersonnaliser.css";
import DatabasePads from "./data/GBA1/Front/ButtonPads";
const colorMap = {
  "rgb(255, 255, 0)": "Yellow",
  "rgb(255, 0, 0)": "Rouge",
  "rgb(0, 128, 0)": "Green",
  "rgb(0, 0, 255)": "Blue",
  "rgb(0, 0, 0)": "Black",
  "rgb(255, 255, 255)": "White",
  "rgb(255, 165, 0)": "Orange",
  "rgb(128, 0, 128)": "rose",
};
function GBAPersonnaliser() {
  // State pour gérer l'image affichée
  const [currentImage, setCurrentImage] = useState(DatabasePads[0].image); // Par défaut, on affiche la première image

  function ChangeColor(e) {
    const button = e.target;

    const buttonClasses = button.classList;

    // On cherche une classe qui correspond à une couleur dans le colorMap
    let colorName;
    buttonClasses.forEach((cls) => {
      if (colorMap[cls]) {
        colorName = colorMap[cls];
      }
    });

    // Cherche l'image correspondante dans DatabasePads en fonction de la couleur
    const pad = DatabasePads.find((pad) => pad.couleur === colorName);

    if (pad) {
      setCurrentImage(pad.image); // Si une correspondance est trouvée, change l'image
    } else {
      console.log("Couleur non trouvée dans DatabasePads");
    }
  }

  return (
    <div className="menu-container">
      <img
        src={Image1}
        className="logo"
        alt="Logo Retrometroid"
        width={300}
        height={300}
      />
      <img src={Image2} className="Overlay" width={300} height={300}></img>

      <div className="accordion">
        <div className="accordion-item">
          <div className="accordion-header">
            BASE CONSOLE <br /> Création à partir d une console que vous
            fournissez
          </div>
          <div className="accordion-body">
            <button className="custom-button">Je fournis la console</button>
            <button className="custom-button">
              Je n ai pas de console à fournir (+40€)
            </button>
          </div>
        </div>

        <div className="accordion-item">
          <div className="accordion-header">
            COQUE <br /> Comprend avant et arrière
          </div>
          <div className="accordion-body">
            <button
              className="color-button Yellow"
              onClick={ChangeColor}
            ></button>
            <button
              className="color-button btn2"
              onClick={ChangeColor}
            ></button>
            <button
              className="color-button btn1"
              onClick={ChangeColor}
            ></button>
            <button
              className="color-button bg-info"
              onClick={ChangeColor}
            ></button>
            <button
              className="color-button bg-primary"
              onClick={ChangeColor}
            ></button>
            <button
              className="color-button bg-secondary"
              onClick={ChangeColor}
            ></button>
            {/* Other color options */}
          </div>
        </div>

        <div className="accordion-item">
          <div className="accordion-header">
            COQUE ARRIERE <br /> Uniquement si la coque arrière est différente
            de l avant
          </div>
          <div className="accordion-body">
            <button className="custom-button">Sans</button>
          </div>
        </div>

        <div className="accordion-item">
          <div className="accordion-header">ECRAN IPS RETROECLAIRE</div>
          <div className="accordion-body"></div>
        </div>

        {/* Additional items... */}

        <div className="accordion-item">
          <div className="accordion-header">ACCESSOIRES</div>
          <div className="accordion-body">
            <button className="custom-button">
              Saccoche Retrometroid (+12,90€)
            </button>
            <br />
            <button className="custom-button">Verre trempé (+4,90€)</button>
            <br />
            <button className="custom-button">Coque silicone (+6,90€)</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GBAPersonnaliser;
