const DataBase = [
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_BLACK0027.png",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_BLUE027.png",
    couleur: "Blue",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_CLEAR_BLACK0027.png",
    couleur: "Clear_Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_CLEAR_BLUE0027.png",
    couleur: "Clear_Blue",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_CLEAR_GLASS0027.png",
    couleur: "Clear_Glass",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_CLEAR_GREEN0027.png",
    couleur: "Clear_Green",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_CLEAR_LEMON0027.png",
    couleur: "Clear_Lemon",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_CLEAR_ROSE0027.png",
    couleur: "Clear_Rose",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_LIGTH_BLUE0027.png",
    couleur: "Light_BLue",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_ORANGE0027.png",
    couleur: "Orange",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_RED027.png",
    couleur: "Red",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_ROSE0027.png",
    couleur: "Rose",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_SNES.png",
    couleur: "Snes",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_VIOLET0027.png",
    couleur: "Clear_Lemon",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_BUTTON_BACK_CLEAR_YELLOW0027.png",
    couleur: "Yellow",
  },
];

export default DataBase;
