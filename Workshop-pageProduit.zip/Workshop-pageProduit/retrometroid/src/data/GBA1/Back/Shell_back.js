const databaseShellB = [
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_BLACK0027.jpg",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_CLEARBLACK0027.jpg",
    couleur: "Clear_Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_CLEARBLUE0027.jpg",
    couleur: "Clear_Blue",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_CLEARGLASS0027.jpg",
    couleur: "Clear_Glass",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_CLEARGREEN0027.jpg",
    couleur: "Clear_Green",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_CLEARORANGE0027.jpg",
    couleur: "Clear_Orange",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_CLEARRED0027.jpg",
    couleur: "Clear_Red",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_CLEARVIOLET0027.jpg",
    couleur: "Clear_Violet",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_CLEARVIOLET-02.jpg",
    couleur: "Clear_Violet1",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_GHOST0027.jpg",
    couleur: "Ghost",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_ROSE0027.jpg",
    couleur: "Rose",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_SPECIAL0027.jpg",
    couleur: "Special",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_TURQUOISE0027.jpg",
    couleur: "Turquoise",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_WHITE0027.jpg",
    couleur: "White",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA_SHELL_BACK_YELLOW0027.jpg",
    couleur: "Yellow",
  },
];

export default databaseShellB;
