const databaseShellB = [
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-BLACK.png",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-BLUE.png",
    couleur: "Blue",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-DARK_ROSE.png",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-GREEN.png",
    couleur: "Green",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-LIGHT_BLUE.png",
    couleur: "Light_Blue",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-ORANGE.png",
    couleur: "Orange",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-RED.png",
    couleur: "Red",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-ROSE.png",
    couleur: "Rose",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-VIOLET.png",
    couleur: "Violet",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-WHITE.png",
    couleur: "White",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-YELLOX.png",
    couleur: "Yellow",
  },
  {
    image: "./assets/GBA/Front/GBA-Back-GBA-BACK-STRA-BLACK.png",
    couleur: "Black",
  },
];

export default databaseShellB;
