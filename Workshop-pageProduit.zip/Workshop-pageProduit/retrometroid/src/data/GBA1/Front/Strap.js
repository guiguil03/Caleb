const DatabaseStrap = [
  {
    image: "./assets/GBA/SIZE/GBA-Side-GBA_SIDE_Strap_Black0027.png",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/SIZE/GBA-Side-GBA_SIDE_Strap_Blue0027.png",
    couleur: "Blue",
  },
  {
    image: "./assets/GBA/SIZE/GBA-Side-GBA_SIDE_Strap_DarkBlue0027.png",
    couleur: "DarkBlue",
  },
  {
    image: "./assets/GBA/SIZE/GBA-Side-GBA_SIDE_Strap_Green0027.png",
    couleur: "Green",
  },
  {
    image: "./assets/GBA/SIZE/GBA-Side-GBA_SIDE_Strap_Orange0027.png",
    couleur: "Orange",
  },
  {
    image: "./assets/GBA/SIZE/GBA-Side-GBA_SIDE_Strap_Red0027.png",
    couleur: "Red",
  },
  {
    image: "./assets/GBA/SIZE/GBA-Side-GBA_SIDE_Strap_Rose0027.png",
    couleur: "Rose",
  },
  {
    image: "./assets/GBA/SIZE/GBA-Side-GBA_SIDE_Strap_White0027.png",
    couleur: "White",
  },
  {
    image: "./assets/GBA/SIZE/GBA-Side-GBA_SIDE_Strap_Yellow0027.png",
    couleur: "Yellow",
  },
];
export default DatabaseStrap;
