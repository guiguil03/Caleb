const DatabaseShell = [
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_BLACK.jpg",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_CLEAR_BLACK.jpg",
    couleur: "Clear_Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_CLEAR_BLUE.jpg",
    couleur: "Clear_Blue",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_CLEAR_GLASS.jpg",
    couleur: "Clear_GLass",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_CLEAR_GREEN.jpg",
    couleur: "Clear_Green",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_CLEAR_ORANGE.jpg",
    couleur: "Clear_Orange",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_CLEAR_RED.jpg",
    couleur: "Clear_Red",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_CLEAR_VIOLET.jpg",
    couleur: "Clear_Violet",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_FAMICON.jpg",
    couleur: "Famicon",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_GHOST.jpg",
    couleur: "Ghost",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_GREY.jpg",
    couleur: "Grey",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_ROSE.jpg",
    couleur: "Rose",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_SNES.jpg",
    couleur: "SNES",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_TURQUOISE.jpg",
    couleur: "Turquoise",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_WHITE.jpg",
    couleur: "White",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_SHELL_YELLOWjpg",
    couleur: "Yellow",
  },
];

export default DatabaseShell;
