const DatabasePads = [
  {
    image: "./data/GBA1/Front/GBA-Front-GBC_LEDGBA_BUTTON_PADS_BLACK.png",
    couleur: "Black",
  },
  {
    image: "./data/GBA1/Front/GBA-Front-GBC_LEDGBA_BUTTON_PADS_BLUE.png",
    couleur: "Blue",
  },
  {
    image: "./data/GBA1/Front/GBA-Front-GBC_LEDGBA_BUTTON_PADS_DARK_BLUE.png",
    couleur: "Dark_Blue",
  },
  {
    image: "./data/GBA1/GBA-Front-GBC_LEDGBA_BUTTON_PADS_GREEN.png",
    couleur: "Green",
  },
  {
    image: "./data/GBA1/Front/GBA-Front-GBC_LEDGBA_BUTTON_PADS_ORANGE.png",
    couleur: "Orange",
  },
  {
    image: "./data/GBA1/Front/GBA-Front-GBC_LEDGBA_BUTTON_PADS_RED.png",
    couleur: "Rouge",
  },
  {
    image: "./data/GBA1/Front/GBA-Front-GBC_LEDGBA_BUTTON_PADS_ROSE.png",
    couleur: "Rose",
  },
  {
    image: "./data/GBA1/Front/GBA-Front-GBC_LEDGBA_BUTTON_PADS_WHITE.png",
    couleur: "White",
  },
  {
    image: "./data/GBA1/Front/GBA-Front-GBC_LEDGBA_BUTTON_PADS_YELLOW.png",
    couleur: "Yellow",
  },
];

export default DatabasePads;
