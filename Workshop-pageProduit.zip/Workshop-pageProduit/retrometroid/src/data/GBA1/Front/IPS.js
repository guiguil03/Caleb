const DatabaseIps = [
  {
    image: "./assets/GBA/Front/GBA-Front-GBA_IPS_BLACK.png",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBA_IPS_DMG.png",
    couleur: "DMG",
  },

  {
    image: "./assets/GBA/Front/GBA-Front-GBA_IPS_SNES_JAP.png",
    couleur: "SNES",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBA_IPS_SNES_US.png",
    couleur: "SNES_US",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBA_IPS_SNES_US_Black.png",
    couleur: "SNES_US_Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBA_IPS_WHITE.png",
    couleur: "White",
  },
];

export default DatabaseIps;
