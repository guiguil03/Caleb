const DataBaseClearButton = [
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_BLACK.png",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_BLUEpng",
    couleur: "Blue",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_CLEAR_BLACK.png",
    couleur: "Clear_Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_CLEAR_BLUE.png",
    couleur: "Clear_Black",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_CLEAR_GLASS.png",
    couleur: "Clear_Glass",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_CLEAR_GREEN.png",
    couleur: "Clear_Green",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_CLEAR_PINK.png",
    couleur: "Clear_Pink",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_LIGHT_BLUE.png",
    couleur: "Light_BLue",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_LIGHT_LEMON.png",
    couleur: "Light_Lemon",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_LIGHT_ORANGE.png",
    couleur: "Light_Orange",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_LIGHT_RED.png",
    couleur: "Light_Red",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-GBC_LEDGBA_BUTTON_LIGHT_YELLOW.png",
    couleur: "Light_Yellow",
  },
];

export default DataBaseClearButton;
