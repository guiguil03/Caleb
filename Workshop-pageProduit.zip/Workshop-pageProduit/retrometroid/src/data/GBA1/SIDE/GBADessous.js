const Database = [
  {
    image: "./assets/GBA/SIDE/GBA-Side-Black_Shell_GBA_0027-side-02.png",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-ClearBlack_Shell_GBA_0027-side-02.png",
    couleur: "Clear_Black",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-ClearBlue_Shell_GBA_0027-side-02.png",
    couleur: "Clear_Blue",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-ClearGlass_Shell_GBA_0027-side-02.png",
    couleur: "Clear_Glass",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-ClearGreen_Shell_GBA_0027-side-02.png",
    couleur: "Clear_Green",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-ClearOrange_Shell_GBA_0027-side-02.png",
    couleur: "Clear_Orange",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-ClearRed_Shell_GBA_0027-side-02.png",
    couleur: "Clear_Red",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-ClearViolet_Shell_GBA_0027-side-02.png",
    couleur: "Clear_Violet",
  },
];

export default Database;
