const DatabaseButon = [
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_Black0027-side.png",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_Blue0027-side.png",
    couleur: "Blue",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_ClearBlack0027-side.png",
    couleur: "Clear_Black",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_ClearBlue0027-side.png",
    couleur: "ClearBlue",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_ClearGlass0027-side.png",
    couleur: "ClearGlass",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_ClearGreen0027-side.png",
    couleur: "ClearGreen",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_ClearPink0027-side.png",
    couleur: "ClearPink",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_Lemon0027-side.png",
    couleur: "Lemon",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_LightBlue0027-side.png",
    couleur: "LigthBlue",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_Red0027-side.png",
    couleur: "Red",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_RoseBlack0027-side.png",
    couleur: "Rose",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_Snes.png",
    couleur: "Snes",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_Violet0027-side.png",
    couleur: "Violet",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_White0027-side.png",
    couleur: "White",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_Yellow0027-side.png",
    couleur: "Yellow",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_Button_Black0027-side.png",
    couleur: "Black",
  },
];

export default DatabaseButon;
