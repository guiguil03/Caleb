const DataBaseSideStrap = [
  {
    image: "./assets/GBA/SIDE/GGBA-Side-GBA_SIDE_Strap_Black-02.png",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/SIDE/GGBA-Side-GBA_SIDE_Strap_Blue-02.png",
    couleur: "Blue",
  },
  {
    image: "./assets/GBA/SIDE/GGBA-Side-GBA_SIDE_Strap_Clear_Rose-02.png",
    couleur: "Clear_Rose",
  },
  {
    image: "./assets/GBA/SIDE/GGBA-Side-GBA_SIDE_Strap_Green-02.png",
    couleur: "Green",
  },
  {
    image: "./assets/GBA/SIDE/GGBA-Side-GBA_SIDE_Strap_LightBlue-02.png",
    couleur: "LightBlue",
  },
  {
    image: "./assets/GBA/SIDE/GGBA-Side-GBA_SIDE_Strap_Orange-02.png",
    couleur: "Orange",
  },
  {
    image: "./assets/GBA/SIDE/GGBA-Side-GBA_SIDE_Strap_Red-02.png",
    couleur: "Red",
  },
  {
    image: "./assets/GBA/SIDE/GGBA-Side-GBA_SIDE_Strap_Rose-02.png",
    couleur: "Rose",
  },
  {
    image: "./assets/GBA/SIDE/GGBA-Side-GBA_SIDE_Strap_Violet-02.png",
    couleur: "Violet",
  },
  {
    image: "./assets/GBA/SIDE/GGBA-Side-GBA_SIDE_Strap_White-02.png",
    couleur: "White",
  },
  {
    image: "./assets/GBA/SIDE/GGBA-Side-GBA_SIDE_Strap_Yellow-02.png",
    couleur: "Yellow",
  },
];
export default DataBaseSideStrap;
