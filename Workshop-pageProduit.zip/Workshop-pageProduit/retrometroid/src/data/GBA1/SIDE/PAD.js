const DatatabasePad = [
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_PAD_Black0027-side.png",
    couleur: "Black",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_PAD_Blue0027-side.png",
    couleur: "BLue",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_PAD_DarkBlue0027-side.png",
    couleur: "DarkBlue",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_PAD_Green0027-side.png",
    couleur: "Green",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_PAD_Orange0027-side.png",
    couleur: "Orange",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_PAD_Red0027-side.png",
    couleur: "Red",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_PAD_Rose0027-side.png",
    couleur: "Rose",
  },

  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_PAD_White0027-side.png",
    couleur: "White",
  },
  {
    image: "./assets/GBA/SIDE/GBA-Side-GBA_PAD_Yellow0027-side.png",
    couleur: "Yellow",
  },
];
export default DatatabasePad;
