const DatabaseSide = [
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_Blanc0027.png",
    couleur: "Blanc",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_Blue.png",
    couleur: "Blue",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_Dark_Rose.png",
    couleur: "Dark_Rose",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_Jaune0027.png",
    couleur: "Blanc",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_LigthBlue.png",
    couleur: "Ligth_Blue",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_Noir0027.png",
    couleur: "Noir",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_Orange0027.png",
    couleur: "Orange",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_Red.png",
    couleur: "Red",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_Rose0027.png",
    couleur: "Rose",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_Shadow.png",
    couleur: "Shadow",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_Violet.png",
    couleur: "Violet",
  },
  {
    image: "./assets/GBA/Front/GBA-Front-01_STRAP_GBA_Blanc0027.png",
    couleur: "Blanc",
  },
];

export default DatabaseSide;
